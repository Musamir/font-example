import {configureStore} from '@reduxjs/toolkit';
import themeReducer from '../reducers/ThemeReducer';

console.log('themeReducer ==>',themeReducer)

export default configureStore({
    reducer: {
        themeChanger: themeReducer
    }
});