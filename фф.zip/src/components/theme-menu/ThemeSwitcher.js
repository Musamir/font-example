import React from 'react'

import Button from 'react-bootstrap/Button';
import {changeMode} from '../../redux/reducers/ThemeReducer';
import {useDispatch} from 'react-redux';

const ThemeMenu = () => {

    const dispatch = useDispatch();
    return (
        <div>
            < Button onClick={() => dispatch(changeMode())}>Change Theme</Button>
        </div>
    )
}

export default ThemeMenu