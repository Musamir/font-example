import './App.css';

import 'bootstrap/dist/css/bootstrap.min.css';
import NavScrollExample from './components/navbar/Navibar';
import {useSelector} from 'react-redux'

function App() {

   const theme = useSelector((state) => state.themeChanger);
   console.log('theme', theme)

  return (
      <div data-bs-theme={theme}>
          <NavScrollExample/>
      </div>
  );
}

export default App;
